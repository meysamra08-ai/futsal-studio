export type ToolType =
  | "player"
  | "goalkeeper"
  | "coach"
  | "referee"
  | "dummy"
  | "ball"
  | "cone"
  | "discCone"
  | "ladder"
  | "pole"
  | "hurdle"
  | "goal"
  | "miniGoal"
  | "dumbbell"
  | "medicineBall"
  | "ring"
  | "bib"
  | "line"
  | "arrow"
  | "curveArrow"
  | "pass"
  | "shot"
  | "dribble"
  | "rectangle"
  | "circle"
  | "text"
  | "eraser"
  | null;

export interface BoardObject {
  id: string;

  type: ToolType;

  x: number;

  y: number;

  rotation: number;

  selected: boolean;

  team?: "blue" | "red";

  number?: number;
}