
import ReactDOM from "react-dom/client";

import App from "./App";

import { ToolProvider } from "./Context/ToolContext";
import { BoardProvider } from "./Context/BoardContext";
import { TeamProvider } from "./Context/TeamContext";

ReactDOM.createRoot(
  document.getElementById("root")!
).render(
 <TeamProvider>
  <BoardProvider>
    <ToolProvider>
      <App />
    </ToolProvider>
  </BoardProvider>
</TeamProvider>
);