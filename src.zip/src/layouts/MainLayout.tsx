import Header from "../components/Header/Header";
import Sidebar from "../components/Sidebar/Sidebar";
import Toolbar from "../components/Toolbar/Toolbar";
import CourtCanvas from "../components/Court/CourtCanvas";
import EquipmentPanel from "../components/Equipment/EquipmentPanel";

export default function MainLayout() {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "260px 1fr 320px",
        gridTemplateRows: "70px 1fr 70px",
        height: "100vh",
        background: "#1f1f1f",
      }}
    >
      {/* Header */}
      <div style={{ gridColumn: "1 / 4" }}>
        <Header />
      </div>

      {/* Sidebar */}
      <Sidebar />

      {/* Court */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflow: "hidden",
          background: "#1f1f1f",
        }}
      >
        <CourtCanvas />
      </div>

      {/* Right Panel */}
      <div
        style={{
          background: "#1f2937",
          borderLeft: "1px solid #444",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
      
        }}
      >
        <EquipmentPanel />
      </div>

      {/* Toolbar */}
      <div style={{ gridColumn: "1 / 4" }}>
        <Toolbar />
      </div>
    </div>
  );
}