import type { BoardObject } from "../../types/BoardObject";
import { objectConfig } from "../../config/objectConfig";

interface Props {
  object: BoardObject;
}

export default function BoardObjectRenderer({ object }: Props) {
  console.log(object);
  const config =
    object.type && object.type in objectConfig
      ? objectConfig[
          object.type as keyof typeof objectConfig
        ]
      : undefined;

  const size = config?.size ?? 40;
  const icon = config?.icon ?? "";

  return (
    <div
      style={{
        width: size,
        height: size,
        transform: `rotate(${object.rotation}deg)` ,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        userSelect: "none",
        pointerEvents: "none",
      }}
    >
      <>
  <img
    src={icon}
    alt={object.type ?? ""}
    draggable={false}
    style={{
      width: "100%",
      height: "100%",
      objectFit: "contain",
    }}
  />

  {object.number && (
    <div
      style={{
        position: "absolute",

        fontWeight: "bold",

        color: "white",

        fontSize: 16,

        textShadow:
          "0 0 4px black",

        pointerEvents: "none",
      }}
    >
      {object.number}
    </div>
  )}
</>
    </div>
  );
}