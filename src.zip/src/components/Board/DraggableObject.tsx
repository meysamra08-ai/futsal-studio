import { useDraggable } from "@dnd-kit/core";

import type { BoardObject } from "../../types/BoardObject";
import BoardObjectRenderer from "./BoardObjectRenderer";

interface Props {
  object: BoardObject;
}

export default function DraggableObject({
  object,
}: Props) {
 
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
  } = useDraggable({
    id: object.id,
  });

  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      
      style={{
        position: "absolute",

        left:
          object.x +
          (transform?.x ?? 0),

        top:
          object.y +
          (transform?.y ?? 0),

        cursor: "grab",
      }}
    >
      <BoardObjectRenderer object={object} />
    </div>
  );
}