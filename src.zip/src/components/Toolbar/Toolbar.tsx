export default function Toolbar() {
  return (
    <div
      style={{
        height: 70,
        background: "#1f2937",
        color: "white",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      Toolbar
    </div>
  );
}