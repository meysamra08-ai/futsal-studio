import { useBoard } from "../../Context/BoardContext";
import { useTool } from "../../Context/ToolContext";

import {
  DndContext,
  type DragEndEvent,
} from "@dnd-kit/core";

import DraggableObject from "../Board/DraggableObject";

export default function CourtCanvas() {
  const { selectedTool } = useTool();

  const {
    objects,
    addObject,
    moveObject,
  } = useBoard();

  return (
    <DndContext
      onDragEnd={(event: DragEndEvent) => {
        const { active, delta } = event;

        const obj = objects.find(
          (o) => o.id === active.id
        );

        if (!obj) return;

        moveObject(
          obj.id,
          obj.x + delta.x,
          obj.y + delta.y
        );
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          overflow: "hidden",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          background: "#00A0E3",
          position: "relative",
        }}
        onClick={(e) => {
          if (!selectedTool) return;

          const rect =
            e.currentTarget.getBoundingClientRect();

          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;

          addObject(selectedTool, x, y);
        }}
      >
        <img
          src="/courts/futsal.png"
          alt="Futsal Court"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "contain",
            userSelect: "none",
            pointerEvents: "none",
          }}
        />

        {objects.map((obj) => (
          <DraggableObject
            key={obj.id}
            object={obj}
          />
        ))}
      </div>
    </DndContext>
  );
}