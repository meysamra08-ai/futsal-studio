import { useTool } from "../../Context/ToolContext";
import { useTeam } from "../../Context/TeamContext";
import Ball from "./Ball";
import { Theme } from "../../theme/theme";

export default function PlayersTab() {
  const { selectedTool, setSelectedTool } = useTool();

  const { currentTeam, toggleTeam } = useTeam();

  const itemStyle = (
    active: boolean
  ): React.CSSProperties => ({
    cursor: "pointer",
    padding: "10px 12px",
    borderRadius: 8,
    marginBottom: 8,

    background: active
      ? Theme.colors.primary
      : "transparent",

    color: Theme.colors.text,

    transition: "0.2s",
  });

  return (
    <div>
      {/* Team */}

      <button
        onClick={toggleTeam}
        style={{
          width: "100%",
          marginBottom: 15,
          padding: 10,
          border: "none",
          borderRadius: 8,
          cursor: "pointer",

          background:
            currentTeam === "blue"
              ? "#1E88E5"
              : "#E53935",

          color: "white",
          fontWeight: "bold",
        }}
      >
        {currentTeam === "blue"
          ? "🔵 Blue Team"
          : "🔴 Red Team"}
      </button>

      {/* Player */}

      <div
        style={itemStyle(
          selectedTool === "player"
        )}
        onClick={() =>
          setSelectedTool("player")
        }
      >
        👤 Player
      </div>

      {/* Goalkeeper */}

      <div
        style={itemStyle(
          selectedTool ===
            "goalkeeper"
        )}
        onClick={() =>
          setSelectedTool(
            "goalkeeper"
          )
        }
      >
        🥅 Goalkeeper
      </div>

      {/* Ball */}

      <div
        style={itemStyle(
          selectedTool === "ball"
        )}
        onClick={() =>
          setSelectedTool("ball")
        }
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <Ball />
          <span>Ball</span>
        </div>
      </div>
    </div>
  );
}