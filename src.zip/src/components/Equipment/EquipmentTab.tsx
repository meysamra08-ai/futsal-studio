import { useTool } from "../../Context/ToolContext";
import Cone from "./Cone";
import { Theme } from "../../theme/theme";

export default function EquipmentTab() {
  const { selectedTool, setSelectedTool } = useTool();

  function itemStyle(active: boolean): React.CSSProperties {
    return {
      cursor: "pointer",
      padding: "10px 12px",
      borderRadius: 8,
      marginBottom: 8,
      background: active
        ? Theme.colors.primary
        : "transparent",
      color: Theme.colors.text,
      transition: "0.2s",
    };
  }

  return (
    <div>
      <h3
        style={{
          color: Theme.colors.text,
          fontSize: Theme.font.subtitle,
          marginBottom: Theme.spacing.md,
        }}
      >
        Equipment
      </h3>

      <div
        style={itemStyle(selectedTool === "cone")}
        onClick={() => setSelectedTool("cone")}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <Cone />
          <span>Cone</span>
        </div>
      </div>

      <div
        style={itemStyle(selectedTool === "ladder")}
        onClick={() => setSelectedTool("ladder")}
      >
        🪜 Ladder
      </div>

      <div
        style={itemStyle(selectedTool === "goal")}
        onClick={() => setSelectedTool("goal")}
      >
        🥅 Goal
      </div>

      <div
        style={itemStyle(selectedTool === "dumbbell")}
        onClick={() =>
          setSelectedTool("dumbbell")
        }
      >
        🏋 Dumbbell
      </div>
    </div>
  );
}