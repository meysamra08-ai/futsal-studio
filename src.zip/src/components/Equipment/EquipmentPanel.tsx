import { useState } from "react";
import PlayersTab from "./PlayersTab";
import EquipmentTab from "./EquipmentTab";
import DrawingTab from "./DrawingTab";
import { Theme } from "../../theme/theme";
import { useTeam } from "../../Context/TeamContext";

type TabType = "players" | "equipment" | "drawing";

export default function EquipmentPanel() {
  const [tab, setTab] = useState<TabType>("players");

  const { currentTeam, toggleTeam } = useTeam();

  const buttonStyle = (
    active: boolean
  ): React.CSSProperties => ({
    flex: 1,
    padding: "12px",
    border: "none",
    cursor: "pointer",

    background: active
      ? Theme.colors.primary
      : Theme.colors.panelSecondary,

    color: Theme.colors.text,

    fontWeight: 600,
  });

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
      }}
    >
      {/* Tabs */}
      <div
        style={{
          display: "flex",
          borderBottom: "1px solid #444444",
        }}
      >
        <button
          style={buttonStyle(tab === "players")}
          onClick={() => setTab("players")}
        >
          👕 Players
        </button>

        <button
          style={buttonStyle(tab === "equipment")}
          onClick={() => setTab("equipment")}
        >
          🛠 Equipment
        </button>

        <button
          style={buttonStyle(tab === "drawing")}
          onClick={() => setTab("drawing")}
        >
          ✏️ Moves
        </button>
      </div>

      {/* Team Selector */}
      <div
        style={{
          padding: 10,
          borderBottom: "1px solid #444",
        }}
      >
        <button
          onClick={toggleTeam}
          style={{
            width: "100%",
            padding: 10,
            border: "none",
            borderRadius: 8,
            cursor: "pointer",
            background:
              currentTeam === "blue"
                ? "#1E88E5"
                : "#E53935",
            color: "white",
            fontWeight: "bold",
            fontSize: 15,
          }}
        >
          {currentTeam === "blue"
            ? "🔵 Blue Team"
            : "🔴 Red Team"}
        </button>
      </div>

      {/* Content */}
      <div
        style={{
          flex: 1,
          padding: 15,
          overflowY: "auto",
        }}
      >
        {tab === "players" && <PlayersTab />}
        {tab === "equipment" && <EquipmentTab />}
        {tab === "drawing" && <DrawingTab />}
      </div>
    </div>
  );
}