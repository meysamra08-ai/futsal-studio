import { useMemo } from "react";

export default function Goalkeeper() {
  const id = useMemo(
    () => goalkeeper-${Math.random()},
    []
  );

  return (
    <svg
      id={id}
      width="34"
      height="34"
      viewBox="0 0 34 34"
    >
      <circle
        cx="17"
        cy="17"
        r="15"
        fill="#43A047"
        stroke="white"
        strokeWidth="2"
      />

      <circle
        cx="17"
        cy="11"
        r="3.5"
        fill="white"
      />

      <path
        d="M10 23
           L24 23"
        stroke="white"
        strokeWidth="2.5"
        strokeLinecap="round"
      />

      <path
        d="M12 18
           L22 18"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
      />

      <path
        d="M17 14
           L17 25"
        stroke="white"
        strokeWidth