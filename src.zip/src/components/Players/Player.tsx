interface Props {
  color?: string;
}

export default function Player({
  color = "#1E88E5",
}: Props) {
  return (
    <svg
      width="34"
      height="34"
      viewBox="0 0 34 34"
    >
      <circle
        cx="17"
        cy="17"
        r="15"
        fill={color}
        stroke="white"
        strokeWidth="2"
      />

      <circle
        cx="17"
        cy="11"
        r="3.5"
        fill="white"
      />

      <path
        d="M11 24
           C11 19
           23 19
           23 24"
        fill="none"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}