import "./Header.css";

export default function Header() {
  return (
    <header className="header">
      <div className="logo">
        ⚽ Coach Studio
      </div>

      <div className="actions">
        <button>Save</button>
        <button>Open</button>
        <button>Export</button>
      </div>
    </header>
  );
}