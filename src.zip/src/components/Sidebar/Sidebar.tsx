import {
  LayoutGrid,
  Users,
  PencilLine,
  FolderOpen,
  Settings,
  Goal,
} from "lucide-react";

import "./Sidebar.css";

export default function Sidebar() {
  return (
    <aside className="sidebar">

      <button className="menu-item">
        <LayoutGrid size={22} />
        <span>Courts</span>
      </button>

      <button className="menu-item">
        <Users size={22} />
        <span>Players</span>
      </button>

      <button className="menu-item">
        <Goal size={22} />
        <span>Equipment</span>
      </button>

      <button className="menu-item">
        <PencilLine size={22} />
        <span>Drawing</span>
      </button>

      <button className="menu-item">
        <FolderOpen size={22} />
        <span>Tactics</span>
      </button>

      <button className="menu-item">
        <Settings size={22} />
        <span>Settings</span>
      </button>

    </aside>
  );
}