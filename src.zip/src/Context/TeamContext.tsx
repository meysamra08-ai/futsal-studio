import {
  createContext,
  useContext,
  useState,
} from "react";
import type { ReactNode } from "react";

export type TeamColor = "blue" | "red";

type TeamContextType = {
  currentTeam: TeamColor;

  setCurrentTeam: (
    team: TeamColor
  ) => void;

  toggleTeam: () => void;
};

const TeamContext =
  createContext<TeamContextType>({
    currentTeam: "blue",

    setCurrentTeam: () => {},

    toggleTeam: () => {},
  });

export function TeamProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [currentTeam, setCurrentTeam] =
    useState<TeamColor>("blue");

  function toggleTeam() {
    setCurrentTeam((prev) =>
      prev === "blue"
        ? "red"
        : "blue"
    );
  }

  return (
    <TeamContext.Provider
      value={{
        currentTeam,
        setCurrentTeam,
        toggleTeam,
      }}
    >
      {children}
    </TeamContext.Provider>
  );
}

export function useTeam() {
  return useContext(TeamContext);
}