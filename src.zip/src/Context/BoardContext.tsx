import {
  createContext,
  useContext,
  useState,
} from "react";

import type { ReactNode } from "react";
import { useTeam } from "./TeamContext";

import type {
  BoardObject,
  ToolType,
} from "../types/BoardObject";

type BoardContextType = {
  objects: BoardObject[];

  addObject: (
    type: ToolType,
    x: number,
    y: number
  ) => void;

  moveObject: (
    id: string,
    x: number,
    y: number
  ) => void;

  setObjects: React.Dispatch<
    React.SetStateAction<BoardObject[]>
  >;
};

const BoardContext =
  createContext<BoardContextType>({
    objects: [],

    addObject: () => {},

    moveObject: () => {},

    setObjects: () => {},
  });

export function BoardProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [objects, setObjects] =
    useState<BoardObject[]>([]);
    const { currentTeam } = useTeam();

  function addObject(
    type: ToolType,
    x: number,
    y: number
  ) {
    if (!type) return;

   const playerCount = objects.filter(
  (o) => o.type === "player"
).length;


const newObject: BoardObject = {
  id: crypto.randomUUID(),

  type,

  x,
  y,

  rotation: 0,

  selected: false,

  number:
    type === "player"
      ? playerCount + 1
      : type === "goalkeeper"
      ? 1
      : undefined,

  team:
  type === "player" ||
  type === "goalkeeper"
    ? currentTeam
    : undefined,
};

console.log("NEW OBJECT", newObject);

    setObjects((prev) => [
      ...prev,
      newObject,
    ]);
  }

  function moveObject(
    id: string,
    x: number,
    y: number
  ) {
    setObjects((prev) =>
      prev.map((obj) =>
        obj.id === id
          ? {
              ...obj,
              x,
              y,
            }
          : obj
      )
    );
  }

  return (
    <BoardContext.Provider
      value={{
        objects,

        addObject,

        moveObject,

        setObjects,
      }}
    >
      {children}
    </BoardContext.Provider>
  );
}

export function useBoard() {
  return useContext(BoardContext);
}
