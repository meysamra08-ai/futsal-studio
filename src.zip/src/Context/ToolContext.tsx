import {
  createContext,
  useContext,
  useState,
} from "react";

import type { ReactNode } from "react";

import type { ToolType } from "../types/BoardObject";

interface ToolContextType {
  selectedTool: ToolType;

  setSelectedTool: (
    tool: ToolType
  ) => void;
}

const ToolContext =
  createContext<ToolContextType>({
    selectedTool: null,

    setSelectedTool: () => {},
  });

export function ToolProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [selectedTool, setSelectedTool] =
    useState<ToolType>(null);

  return (
    <ToolContext.Provider
      value={{
        selectedTool,
        setSelectedTool,
      }}
    >
      {children}
    </ToolContext.Provider>
  );
}

export function useTool() {
  return useContext(ToolContext);
}