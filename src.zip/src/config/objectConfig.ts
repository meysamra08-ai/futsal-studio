export const objectConfig = {
  player: {
    size: 60,
    icon: "/equipment/player.svg",
  },

  goalkeeper: {
    size: 60,
    icon: "/equipment/goalkeeper.svg",
  },

  coach: {
    size: 60,
    icon: "/equipment/coach.svg",
  },

  referee: {
    size: 60,
    icon: "/equipment/referee.svg",
  },

  dummy: {
    size: 60,
    icon: "/equipment/dummy.svg",
  },

  ball: {
    size: 28,
    icon: "/equipment/ball.svg",
  },

  cone: {
    size: 24,
    icon: "/equipment/cone.svg",
  },

  discCone: {
    size: 24,
    icon: "/equipment/discCone.svg",
  },

  ladder: {
    size: 90,
    icon: "/equipment/ladder.svg",
  },

  pole: {
    size: 70,
    icon: "/equipment/pole.svg",
  },

  hurdle: {
    size: 60,
    icon: "/equipment/hurdle.svg",
  },

  goal: {
    size: 120,
    icon: "/equipment/goal.svg",
  },

  miniGoal: {
    size: 80,
    icon: "/equipment/miniGoal.svg",
  },

  medicineBall: {
    size: 35,
    icon: "/equipment/medicineBall.svg",
  },

  dumbbell: {
    size: 35,
    icon: "/equipment/dumbbell.svg",
  },

  ring: {
    size: 35,
    icon: "/equipment/ring.svg",
  },

  bib: {
    size: 35,
    icon: "/equipment/bib.svg",
  },
} as const;